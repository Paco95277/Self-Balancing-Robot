#include "delay.h"
#include "sys.h"
#include "pwm.h"
#include "usart.h"
#include "math.h"
#include "string.h"
#include "encoder.h"
#include "timer.h"
#include "usart2.h"
#include "usart3.h"
#include "string.h"
#include <stdlib.h>

/****************************************
Selbstbalancierendes Fahrzeug

Hardware: STM32F103RCT6 als Hauptkontroller
          TB6612FNG als Motorantrieb
					12V Gleichstrommotor mit 334-Impulse-Drehgeber 
					MPU6050 als Beschleunigungssensor
					HC05 als Medium zwischen Hauptkontroller und Bedienteil

****************************************/
#define PI 3.14159

float a[3],w[3],angle[3],T;
extern u8 Re_buf[11],counter;
extern u8 sign;
extern u8 Command[8],point;
u8 Command2[8],i;
float PWM, PWM_L, PWM_R;
float Kp_angle = 65.0, Kd_angle = 5.1, Kp_speed = -1.0, Ki_speed = -0.005;
float err, speed_need = 0,turn_need = 0;	 //speed_need = 300,turn_need = 20
float position_dot, position_dot_filter, position;
float setPoint = -1.3;//Mechanischer Nullpunkt, minus steht fuer nach Kupfer-Saeule

void PID(void)
{
	
	if(angle[1]<-35 || angle[1]>35) //Neigungswinkel zu gross, Motoren ausschalten
	{  
	    M1_1 = 1;
			M1_2 = 1; //Motor1 ausschalten
			M2_1 = 1;
			M2_2 = 1; //Motor2 ausschalten
	    M_stby = 0;
		return;
	}
  err = angle[1] - setPoint; //tatsaechlicher Neigungswinkel
	PWM = err * Kp_angle + w[1] * Kd_angle + position_dot_filter * Kp_speed + position * Ki_speed;//PID-Algorithmus	 
	PWM_L = PWM + turn_need ; //abbiegen
	PWM_R = PWM - turn_need ;
	motor_speed(PWM_L, PWM_R); //Motor Ausgabe
//	motor_speed(120, 120);//-r -l +l +r
}

void TIM4_IRQHandler(void)  //TIM4 Overflow Interrupt  
{
	if (TIM_GetITStatus(TIM4, TIM_IT_Update) != RESET) 
		{	
			TIM_ClearITPendingBit(TIM4, TIM_IT_Update  ); //Interrupt-Flag zuruecksetzen
			
			position_dot = (TIM2_Encoder_Read_1() + TIM3_Encoder_Read_2())/2; //die Encoder-Werte ablesen
			TIM2_Encoder_Write_1(0);   //Encoder wieder zuruecksetzen
			TIM3_Encoder_Write_2(0);   //Encoder wieder zuruecksetzen
			position_dot_filter	*= 0.85;//Tiefpass, um Stoerung zu unterdruecken
			position_dot_filter += position_dot * 0.15; //die Fahrgeschwindigkeit
			
			position +=	position_dot_filter;  //die Fahrgeschwindigkeiten summieren und die Summe ist die Strecke
			if(position > 40000)   
			{
				position = 40000; 
			}
			else if(position < -40000)
			{
				position = -40000;
			}
			
			PID();
		}
}


int main(void)
{	
	unsigned char Temp[11];
	NVIC_Configuration();
 
	delay_init();	//delay-Funktionen initialisieren
	M_Init();
	TIM1_PWM_Init(900,0); //keine Prescale, fpwm=72000/(899+1)=80Khz 
	GPIO_PinRemapConfig(GPIO_Remap_SWJ_JTAGDisable, ENABLE);
	TIM2_Encoder_Init_1(0xffff, 0);
	TIM3_Encoder_Init_2(0xffff, 0);
	TIM4_Int_Init(99,7199);//10ms Overflow-Interrupt 
	uart_init(9600);
	USART2_Init(19200);
	USART3_Init(115200);
	delay_ms(50);
	while(1)
	{
//			printf("%d \r\n",TIM2_Encoder_Read_1());delay_ms(50);
//			printf("%d \r\n",TIM3_Encoder_Read_2());delay_ms(50);
		if(USART2_RX_STA_C&0X8000)//Steuersignale vom Bedienteil
		{	
			USART2_RX_STA_C=0;	
 			switch(Command[1])
			{
				 case 1:speed_need = -300; turn_need = 0;;break; //nach vorne
				 case 2:speed_need = 300; turn_need = 0;break; //nach hinten
				 case 3:turn_need = 30; speed_need = 0;break; //nach links
				 case 4:turn_need = -30; speed_need = 0;break; //nach rechts
				 case 5:turn_need = 0; speed_need = 0;break;  //stop
				 default:break;
			}
		}

		if(sign) //Daten vom MPU6050
		{  
			 memcpy(Temp,Re_buf,11);
		   sign=0;
			 if(Re_buf[0]==0x55) //Daten empfangen
			 {  
					switch(Re_buf[1]) //Header
					{
						 case 0x51: //Header fuer Beschleunigung
							//a[0] = ((short)(Re_buf[3]<<8 | Re_buf[2]))/32768.0*16;      //X-Achse
							//a[1] = ((short)(Re_buf[5]<<8 | Re_buf[4]))/32768.0*16;      //Y-Achse
							//a[2] = ((short)(Re_buf[7]<<8 | Re_buf[6]))/32768.0*16;      //Z-Achse
							//T    = ((short)(Re_buf[9]<<8 | Re_buf[8]))/340.0+36.25;      //Temperatur
							break;
						 case 0x52: //Header fuer Winkelgeschwindigkeit
							//w[0] = ((short)(Re_buf[3]<<8| Re_buf[2]))/32768.0*2000;      //X-Achse
							w[1] = ((short)(Re_buf[5]<<8| Re_buf[4]))/32768.0*2000;      //Y-Achse
							//w[2] = ((short)(Re_buf[7]<<8| Re_buf[6]))/32768.0*2000;      //Z-Achse
							//T    = ((short)(Re_buf[9]<<8| Re_buf[8]))/340.0+36.25;      //Temperatur
							break;
						 case 0x53: //Header fuer Winkel
							//angle[0] = ((short)(Re_buf[3]<<8| Re_buf[2]))/32768.0*180;   //X-Achse
							angle[1] = ((short)(Re_buf[5]<<8| Re_buf[4]))/32768.0*180;   //Y-Achse
							//angle[2] = ((short)(Re_buf[7]<<8| Re_buf[6]))/32768.0*180;   //Z-Achse
							//T   = ((short)(Re_buf[9]<<8| Re_buf[8]))/340.0+36.25;   //Temperatur
							break;
						 default:  break;
					}
			  }
		  }
      
	} 
	 
}

