#ifndef __ENCODER_H
#define __ENCODER_H
#include "sys.h"


void TIM2_Encoder_Init_1(u16 arr,u16 psc);
void TIM2_Encoder_Write_1(int data);
int TIM2_Encoder_Read_1(void);

void TIM3_Encoder_Init_2(u16 arr,u16 psc);
void TIM3_Encoder_Write_2(int data);
int TIM3_Encoder_Read_2(void);
#endif
