#ifndef __PWM_H
#define __PWM_H
#include "sys.h"
#define M1_1 PCout(0)
#define M1_2 PCout(1)
#define M2_1 PCout(2)
#define M2_2 PCout(3)
#define M_stby PCout(4)
//#define M_s PCout(5)

void M_Init(void);
void TIM1_PWM_Init(u16 arr,u16 psc);
void motor_speed(s16 motor1,s16 motor2);

#endif
