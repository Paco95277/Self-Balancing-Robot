#include "pwm.h"
	  
void M_Init(void)
{
	GPIO_InitTypeDef  GPIO_InitStructure;
	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC,ENABLE);
	GPIO_InitStructure.GPIO_Pin=GPIO_Pin_0;
	GPIO_InitStructure.GPIO_Mode=GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_Init(GPIOC, &GPIO_InitStructure);
	GPIO_SetBits(GPIOC, GPIO_Pin_0);
	
	GPIO_InitStructure.GPIO_Pin=GPIO_Pin_1;
	GPIO_Init(GPIOC, &GPIO_InitStructure);
	GPIO_SetBits(GPIOC, GPIO_Pin_1);
	
	GPIO_InitStructure.GPIO_Pin=GPIO_Pin_2;
	GPIO_Init(GPIOC, &GPIO_InitStructure);
	GPIO_SetBits(GPIOC, GPIO_Pin_2);
	
	GPIO_InitStructure.GPIO_Pin=GPIO_Pin_3;
	GPIO_Init(GPIOC, &GPIO_InitStructure);
	GPIO_SetBits(GPIOC, GPIO_Pin_3);
	
	GPIO_InitStructure.GPIO_Pin=GPIO_Pin_4;
	GPIO_Init(GPIOC, &GPIO_InitStructure);
	GPIO_SetBits(GPIOC, GPIO_Pin_4);
	
	
}

void TIM1_PWM_Init(u16 arr,u16 psc)
{  
	 GPIO_InitTypeDef GPIO_InitStructure;
	TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;
	TIM_OCInitTypeDef  TIM_OCInitStructure;

	RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM1, ENABLE);
 	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA , ENABLE);
	                                                                     	
	GPIO_InitStructure.GPIO_Pin=GPIO_Pin_8;
	GPIO_InitStructure.GPIO_Mode=GPIO_Mode_AF_PP;
	GPIO_InitStructure.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
	GPIO_SetBits(GPIOA, GPIO_Pin_8);
	
	GPIO_InitStructure.GPIO_Pin=GPIO_Pin_11;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
	GPIO_SetBits(GPIOA, GPIO_Pin_11);

	
	TIM_TimeBaseStructure.TIM_Period = arr; //80K
	TIM_TimeBaseStructure.TIM_Prescaler = psc;
	TIM_TimeBaseStructure.TIM_ClockDivision = 0;
	TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
	TIM_TimeBaseInit(TIM1, &TIM_TimeBaseStructure);

 
	TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1;
	TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
	TIM_OCInitStructure.TIM_Pulse = 0;
	TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;
	TIM_OC4Init(TIM1, &TIM_OCInitStructure);
	TIM_OC1Init(TIM1, &TIM_OCInitStructure); 
	
  TIM_CtrlPWMOutputs(TIM1,ENABLE);

	TIM_OC4PreloadConfig(TIM1, TIM_OCPreload_Enable); 
	TIM_OC1PreloadConfig(TIM1, TIM_OCPreload_Enable);
	
	TIM_ARRPreloadConfig(TIM1, ENABLE);
	
	TIM_Cmd(TIM1, ENABLE);
 
   
}

void motor_speed(s16 motor1,s16 motor2)
{
	s16 motor1speed = 0, motor2speed = 0;
	
	if(motor1>400)  motor1speed = 400;
	    else if (motor1<-400)  motor1speed = -400;
			else  motor1speed = motor1;
	if(motor2>400)  motor2speed = 400;
	    else if (motor2<-400)  motor2speed = -400;
			else  motor2speed = motor2;
	if(motor1speed == 0) //ɲ��
	{
		M1_1 = 1;
		M1_2 = 1;
		TIM1->CCR1 = 0;
	}
    else if(motor1speed > 0)
	{
		M1_1 = 1;
		M1_2 = 0;
		TIM1->CCR1 = motor1speed;
	}
	else
	{
		M1_1 = 0;
		M1_2 = 1;
		TIM1->CCR1 = -motor1speed;
    }

	if(motor2speed == 0)
	{
		M2_1 = 1;
		M2_2 = 1;
		TIM1->CCR4 = 0;
	}
	else if(motor2speed > 0)
	{
		M2_1 = 0;
		M2_2 = 1;
		TIM1->CCR4 = motor2speed;
	}
	else
	{
		M2_1 = 1;
		M2_2 = 0;
		TIM1->CCR4 = -motor2speed;
	}
}

	




