#ifndef __KEY_H
#define __KEY_H	 
#include "sys.h"

#define KEY0 PCin(5)   	
#define KEY1 PAin(15)	 
#define WK_UP PAin(0)	 
 

//#define KEY0  GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_0)//��ȡ����0
//#define KEY1  GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_1)//��ȡ����1
//#define KEY2  GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_2)
 

#define KEY0_PRES	1		//KEY0  
#define KEY1_PRES	2		//KEY1 
#define WKUP_PRES	3		//WK_UP  
//#define KEY2_PRES 3

void KEY_Init(void);//IO��ʼ��
u8 KEY_Scan(u8 mode);  	//����ɨ�躯��					    
#endif
